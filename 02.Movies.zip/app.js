import {
    navBar
} from "./nav.js";

import {
    homePage
} from "./homePage.js"

homePage();

navBar();